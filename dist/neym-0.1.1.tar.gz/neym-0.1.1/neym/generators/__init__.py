"""Generators package for neym library."""
from .name_generator import generate_turkish_name

__all__ = ["generate_turkish_name"]
