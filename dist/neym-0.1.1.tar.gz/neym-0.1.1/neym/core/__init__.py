"""Core package for neym library."""
from .randomizer import names

__all__ = ["names"]
